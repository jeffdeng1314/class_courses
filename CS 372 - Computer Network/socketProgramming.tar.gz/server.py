import socket

s = socket.socket()
host = "localhost"

port = 8080
print("Port: ", port)

s.bind((host,port))
s.listen(1)

print(host)
print("Waiting for any incoming connections...")

conn, addr = s.accept()

print(addr, "Has connected to the server")

from_client = conn.recv(4096)


if from_client.decode().split()[0] == 'get':
    file = open(from_client.split()[1], 'rb')
    while True:
        file_data = file.read(4096)
        if not file_data: break
        conn.send(file_data)

    print("Data has been transmitted successfully!")
    file.close()