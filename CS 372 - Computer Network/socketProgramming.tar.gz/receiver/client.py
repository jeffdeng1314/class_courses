import socket

s = socket.socket()
host = "localhost"

port = int(input("Please specify a port: "))


s.connect((host,port))

print("Connected ...")

command = str(input("Please specify the filename along with \"get\" command: "))
s.send(command.encode())

file = open(command.split()[1], 'wb')
from_server = ''

while True:
    data = s.recv(4096)
    if not data:
        break
    file.write(data)

file.close()
print("File has been received successfully!")
