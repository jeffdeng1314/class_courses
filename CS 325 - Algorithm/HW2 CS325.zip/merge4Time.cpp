//  Name: Hao (Jeff) Deng 
//  ID: 932912420
//  Assignment: Assignment 2 (CS 325)


#include <iostream>
#include <cstdlib> 
#include <fstream>
#include <vector>
#include <ctime>

using namespace std;

//defining a range to check if the array size will exceed this 
#define RANGE_SIZE 90000
// #define SIZE_OF_ARRAY 50000

//Reference from:
//https://www.geeksforgeeks.org/3-way-merge-sort/
//This is the merging function, which will merge the two arrays together recursively
void merging (int *array, int left, int mid1, int mid2, int mid3, int right){

    // int first=left, second=mid1, third=mid2, fourth=mid3;
    // int min_low = left;

    int a=0, b=0, c=0, d=0, temp=left;

    //values for the four sub-arrays
    int l1 = mid1 - left + 1;
    int l2 = mid2 - mid1;
    int r1 = mid3 - mid2;
    int r2 = right - mid3;


    //creating two vectors for left and right
    int left_one_array [l1];
    int left_second_array [l2];
    int right_one_array [r1];
    int right_second_array [r2] ;

    int i  , j;
    //Pushing to the first left array
    for( i=0;i<l1;i++){
        int x = array[left + i];
        left_one_array[i] = x;
    }
    left_one_array[i] = RANGE_SIZE; 

    //Pushing to the second left array
    for( i=0;i<l2;i++){
        int x = array[mid1 + 1 + i];
        left_second_array[i] = x;
    }
    left_second_array[i] = RANGE_SIZE; 

    //Pushing to the first right array
    for( j=0;j<r1;j++){
        int x = array[mid2 + 1 + j];
        right_one_array[j] = x;
      
    }
    right_one_array[j] = RANGE_SIZE; 
        
    //Pushing to the second right array
    for( j=0;j<r2;j++){
        int x = array[mid3 + 1 + j];
        right_second_array[j] = x;
    }
    right_second_array[j] = RANGE_SIZE; 
    // Assigning temp as left as a point to start
    // temp = left;

    
    // Taking the smaller from the smallest numbers from the arrays
    while((a < l1 && b < l2) && (c < r1 && d < r2)){
            // cout<<"temp: "<<temp<<endl;

        if(left_one_array[a] != RANGE_SIZE || left_second_array[b] != RANGE_SIZE || right_one_array[c] != RANGE_SIZE || right_second_array[d] != RANGE_SIZE){
        // cout<<"temp: "<<temp<<endl;
        //Comparing the values and assign the least to the left of the array
        // if(left_one_array[a] <= left_second_array[b]){
          
        //     if(left_one_array[a] <= right_one_array[c]){
               
        //         if(left_one_array[a] <= right_second_array[d])
        //             array[temp] = left_one_array[a++];
        //         else
        //             array[temp] = right_second_array[d++];
        //     }
        //     else{
        //         if(right_one_array[a] <= right_second_array[d])
        //             array[temp] = right_one_array[c++];
        //         else
        //             array[temp] = right_second_array[d++];
        //     }

        //     // int x = left_array[a];
        //     // array[temp] = x;
        //     // a++;
        // }
        // else if(left_second_array[b] <= right_one_array[c]){
        //     if(left_second_array[b] < right_second_array[d])
        //         array[temp] = left_second_array[b++];
        //     else
        //         array[temp] = right_second_array[d++];
        // }
        // else{

        //     // cout<<"hi"<<right_one_array[c]<<endl;
        //     if(right_one_array[c] <= right_second_array[d])
        //         array[temp] = right_one_array[c++];
        //         // cout<<"Hi"<<endl;
        //     else
        //         // cout<<"asldkfj"<<endl;
        //         array[temp] = right_second_array[d++];

        //     // int x = right_array[b];
        //     // array[temp] = x;
        //     // b++;
           
        // }

        //if the first left array value is lesser than the first value of the rest
        if((left_one_array[a] < left_second_array[b]) && (left_one_array[a] < right_one_array[c]) && (left_one_array[a] < right_second_array[d])){
            array[temp++] = left_one_array[a++];
           
            
        }

        //if the second left array value is lesser than the first value of the rest
        else if((left_second_array[b] < left_one_array[a]) && (left_second_array[b] < right_one_array[c]) && (left_second_array[b] < right_second_array[d])){
            array[temp++] = left_second_array[b++];
            

        }
       
       //if the first right array value is lesser than the first value of the rest
        else if((right_one_array[c] < left_one_array[a]) && (right_one_array[c] < left_second_array[b]) && (right_one_array[c] < right_second_array[d])){
            array[temp++] = right_one_array[c++];
            
         
        }

       //if the second right array value is lesser than the first value of the rest
        else if((right_second_array[d] < left_one_array[a]) && (right_second_array[d] < left_second_array[b]) && (right_second_array[d] < right_one_array[c])){
            array[temp++] = right_second_array[d++];
            
            
        }
        //everything else
        else{
            if((left_one_array[a] <= left_second_array[b])){
                array[temp++] = left_one_array[a++];
                
            }
            else{
                array[temp++] = left_second_array[b++];
                
            }
        }
        
        // temp++; 
        }
        // temp++; 
    }

}


//This is the mergeSort function where the recursion is called 
void mergeSort(int *array, int left, int right){

    if(left < right){
        // if (right - left < 2)
        // return;
    //Splitting into four parts
    int mid2 = left+(right - left)/2; //Setting the first middle value
    int mid1 = left + (mid2 - left)/2; //Setting the second middle value
    int mid3 = mid2 + (right - mid2)/2;

    mergeSort(array, left, mid1); //first quarter
    mergeSort(array, mid1+1, mid2);//second quarter
    mergeSort(array, mid2+1, mid3);//third quarter
    mergeSort(array, mid3+1, right);//last quarter
    merging(array, left, mid1, mid2, mid3, right);//merge them

    }
}

// Calling the mergeSort function
void mergeSortFourWays(int *array, int array_size){

  
    mergeSort(array,0,array_size);

}




//Reference to my previous merge sort program
//Merge sort reference:
//https://www.geeksforgeeks.org/merge-sort/
int main(){

    srand (time(NULL));
     clock_t t;
    int array_size;
    int temp_var;

    int n =0;
    int random;

    for(int i=0;i<10;i++){
        n = n + 50000;
        int array[1000000];
        for(int j=0;j<n;j++){
            random = rand()%100001;
            array[j] = random;
        }


        t = clock();

            // Calling the merge function
        mergeSortFourWays(array, n-1);
        
        t = clock() - t;

        cout<<"Array Size: "<<n<<endl;
        cout<<"Time: "<<((float)t)/CLOCKS_PER_SEC << " seconds"<<endl;
        cout<<endl;

    }


    return 0;
}
