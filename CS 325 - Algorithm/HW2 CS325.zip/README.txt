Written in C++
Compile with g++ <cpp file> -o <any appropriate name>
ex). g++ merge4.cpp -o mergeSort
ex). g++ merge4Time.cpp -o mergeTime