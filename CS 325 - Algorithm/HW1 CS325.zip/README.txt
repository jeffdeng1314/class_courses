Written in C++
Compile with g++ <cpp file> -o <any appropriate name>
ex). g++ mergesort.cpp -o mergeSort
ex). g++ insertsort.cpp -o insertSort
ex). g++ mergeTime.cpp -o merge_time
ex). g++ insertTime.cpp -o insert_time
