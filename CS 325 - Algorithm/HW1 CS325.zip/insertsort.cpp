#include <iostream>
#include <cstdlib> 
#include <fstream>
#include <vector>

using namespace std;

//Insertion sort with vector array. Reference from:
//https://www.geeksforgeeks.org/insertion-sort/
//Psuedocode from: 
//https://www.ee.ryerson.ca/~courses/coe428/sorting/insertionsort.html
void insertion(vector <int> &array, int array_size ){ //passing the vector by reference

    //opening a file for output
    // ofstream output_file;

    int temp;
    int j;
    for(int i=1;i<array_size;i++){

        temp = array[i];
        j = i-1;

        while(j>=0 && array[j]>temp){
            array[j+1] = array[j];
            j = j-1;
        }
        array[j+1] = temp;

    }

}


//This is the main function where data will be read from data.txt and sort them
int main(){

    ifstream myfile ("data.txt");
    int array_size;
    int temp_var;

    //Opens the file 
    if (myfile.is_open()){
        while (!myfile.eof()){
            //declaring a vector int array
            vector <int> array;
            myfile >> array_size;//Assigning the first index value into a variable for the array size

            //Puts the number inside the vector array
            for(int i=0;i<array_size;i++){
                myfile >> temp_var;
                array.push_back(temp_var);
            }

            //Calling the insertion function
            insertion(array,array_size);
            
            ofstream output_file;
            output_file.open("insert.txt", ios::app) ;
            for(int i=0;i<array_size;i++)
                output_file << array[i] << " ";
            output_file << endl;
            output_file.close();
        }
        //closing the file
        myfile.close();
    }
    //if the file cannot be opened
    else
        cout<<"Can't open"<<endl;

    return 0;

}
