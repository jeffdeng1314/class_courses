#include <iostream>
#include <cstdlib> 
#include <fstream>
#include <vector>
#include <ctime>



using namespace std;

//Insertion sort with vector array. Reference from:
//https://www.geeksforgeeks.org/insertion-sort/
//Psuedocode from: 
//https://www.ee.ryerson.ca/~courses/coe428/sorting/insertionsort.html
void insertion(vector <int> &array, int array_size ){ //passing the vector by reference

    //opening a file for output
    // ofstream output_file;

    int temp;
    int j;
    
    for(int i=1;i<array_size;i++){
        temp = array[i];
        j = i-1;

        //going back to the array
        while(j>=0 && array[j]>temp){
            array[j+1] = array[j];
            j = j-1;
        }
        array[j+1] = temp;

    }

}


//This is the main function where data will be read from data.txt and sort them
int main(){

    srand (time(NULL));
    clock_t t;

    // int ten_arrays
    int n=0;
    int random_num; 
    for(int i=0;i<10;i++){
        
        n = n + 5000; //size of the array
        vector <int> array;
       array.reserve(n);//making the space for the vector
        
        for(int j=0;j<n;j++){
            random_num = rand()%100001; //randomly generating the numbers
            array.push_back(random_num);
        }

        //Reference from:
        //http://www.cplusplus.com/reference/ctime/clock/
        t = clock();
        insertion(array,n);
        t = clock() - t;
        cout<<"Array Size: "<<n<<endl;
        cout<<"Time: "<<((float)t)/CLOCKS_PER_SEC << " seconds"<<endl;
        cout<<endl;
    }

    return 0;

}
