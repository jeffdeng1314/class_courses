#include <iostream>
#include <cstdlib> 
#include <fstream>
#include <vector>

using namespace std;


//This is the merging function, which will merge the two arrays together recursively
void merging (vector <int> &array, int left, int right, int middle ){

    int first=0, second=0,temp;

    //left value and right value
    int l1 = middle - left + 1;
    int r1 = right - middle;

    //creating two vectors for left and right
    vector <int> left_array ;
    vector <int> right_array;

    //Pushing to the left array
    for(int i=0;i<l1;i++){
        int x = array[left + i];
        left_array.push_back(x);
    }
    //Pushing to the right array
    for(int j=0;j<r1;j++){
        int x = array[middle + 1 + j];
        right_array.push_back(x);
    }
    //Assigning temp as left as a point to start
    temp = left;

    //while if the first is less than the left values and second is less than right
    while(first < l1 && second < r1){
        //Comparing the values and assign the least to the left of the array
        if(left_array[first] <= right_array[second]){
            int x = left_array[first];
            array[temp] = x;
            first++;
        }
        else{
            int x = right_array[second];
            array[temp] = x;
            second++;
           
        }
        temp++;
    }

    //This is the left overs from the left side
    while(first < l1){
        int x = left_array[first];
        array[temp] = x;
        first++;
        temp++;
    }

    //left overs from the right side
    while(second < r1){
        int x = right_array[second];
        array[temp] = x;
        second++;
        temp++;
    }


}


//This is the mergeSort function where the recursion is called 
void mergeSort(vector <int> &array, int left, int right){

    if (left < right){

        int middle = left+(right-left)/2; //Setting the middle value

        mergeSort(array, left, middle ); //left side
        mergeSort(array, middle+1, right);//right side
        merging(array, left, right, middle);//merge them
    }
    
}


//Merge sort reference:
//https://www.geeksforgeeks.org/merge-sort/
int main(){

    ifstream myfile ("data.txt");
    
    int array_size;
    int temp_var;

    //Opens the file 
    if (myfile.is_open()){
        while (!myfile.eof()){
            //declaring a vector int array
            vector <int> array;
            myfile >> array_size;//Assigning the first index value into a variable for the array size

            //Puts the number inside the vector array
            for(int i=0;i<array_size;i++){
                myfile >> temp_var;
                array.push_back(temp_var);
            }


            // Calling the merge function
            mergeSort(array, 0, array_size-1);
            

            //outputting the values to the file
            ofstream output_file;
            output_file.open("merge.txt", ios::app);
            for(int i=0;i<array_size;i++)
                output_file << array[i] << " ";
            output_file <<endl;
            output_file.close();
        }
        //closing the file
        myfile.close();
    }
    //if the file cannot be opened
    else
        cout<<"Can't open"<<endl;

    return 0;
}