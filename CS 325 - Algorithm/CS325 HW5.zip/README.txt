This program is written is C++
Please compile the code with:
    "g++ wrestler.cpp -o wrestler"

And then excute the program by entering 
    "wrestler" follow by the name of the text file in the command line.
For example,
    "wrestler wrestler.txt"
    "wrestler wrestler1.txt"
    "wrestler wrestler2.txt"

Please make sure that wrestler.txt, wrestler1.txt, and wrestler2.txt
are one the same folder.
