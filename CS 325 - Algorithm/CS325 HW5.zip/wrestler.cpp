//Program: CS 325 HW 5
//Name: Hao(Jeff) Deng
//ID: 932912420

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <string>
#include <map>
using namespace std;


//This function does the comparison for the pairs in case if the previous statements didn't catch any empty wrestlers
int pair_comparing(int check,int i, string first,string second,string rivalries_array[][2],map<string, string> &map_storage){

    //determines if one is the same but the other one is not, then set that one to the same
    if(map_storage[rivalries_array[i][1]] == first && map_storage[rivalries_array[i][0]] != second){
        map_storage[rivalries_array[i][0]] = second;
        return 1;
    }
    return check;//If the "if" statement is not excuted, then just return whatever check is 
}


//This is used to compare the pairs and assign the opposite type if the condition is met
int comparing(int check, int i, string first, string second,string rivalries_array[][2],map <string, string> &map_storage){
    if(map_storage[rivalries_array[i][1]] == first){
        cout<<"No, impossible"<<endl; //If the two has the same type, then it is impossible to pair them up
        return -1;
    }
    else if (map_storage[rivalries_array[i][1]] != second){ //else assign the opposite type to the second candidate if the condition is met
        map_storage[rivalries_array[i][1]] = second;
        return 1;
    }
}

//This is the printing function, it is used to print out the babyfaces and heels
void printing(int n, string word, string wrestler_array[], map<string, string> map_storage){
    for(int i=0;i<n;i++){
        if(map_storage[wrestler_array[i]] == word)
            cout<<wrestler_array[i]<<" ";
    }
    cout<<endl;
}

//This is the BFS function, it is used to make comparisons and assignments, in the end we will print out a list of babyfaces and heels
void bfs(int n, int m, string wrestler_array[], string rivalries_array[][2],map <string, string> &map_storage){
    int condition = 1;
    string first,second;
    first = "Babyface";
    second = "Heel";
    while(condition == 1){
        int check = 0;
    
        for(int i=0;i<m;i++){//Going through the whole paring list
            if(map_storage[rivalries_array[i][0]] == first) //If the first wrestler is babyface
                check = comparing(check,i,first,second,rivalries_array,map_storage);
            if (map_storage[rivalries_array[i][0]] == second) //If the second wrestler is heel
                check = comparing(check,i,second,first,rivalries_array,map_storage);
            if(check < 0) //If the paring is not compatible, then exit the program
                return;
            check = pair_comparing(check,i,first,second,rivalries_array,map_storage); //make sure nothing is left out
            check = pair_comparing(check,i,second,first,rivalries_array,map_storage);
        }

        //If check is 0, means that we maybe left something out, and we will
        //go through the list to make sure everything is filled.
        if(check == 0){
            for(int j=0;j<n;j++){
                if(map_storage[wrestler_array[j]] == "Empty"){
                    map_storage[wrestler_array[j]] = first;
                    check = 1;
                    break;
                }
            }
            //If check is still 0, that means we are done
            if(check == 0)
                condition = 0;
        }
    }

    //These only executes if the algorithm works with the given inputs
    cout<<"Yes, it is possible"<<endl;
    cout<<first<<"s: ";
    printing(n,first,wrestler_array,map_storage);
    cout<<second<<"s: ";
    printing(n,second,wrestler_array,map_storage);
    cout<<endl;
} 

//This is the main function, where the user can enter the text file in the command line when executing the program
int main(int argc, char* argv[]){

    fstream file;
    int n,m;
    string input,first,second;
    //Making a map container to hold the wrestlers with unique keys and their values
    map <string, string> map_storage;

    //Check if there are more or less than two arguments
    if (argc != 2){
        cout<<"Please enter the correct file"<<endl;
        exit(1);
    }
    
    //Opens the file that the user input
    file.open(argv[1]);

    if(file.is_open()){
        
        // cout<<argv[1]<<endl;
        file >> n;
        string wrestler_array[n];
        // cout<<n<<endl;
        //Assinging the wrestlers with empty value in the map container
        for(int i=0;i<n;i++){
            file >> input;
            wrestler_array[i] = input;
            map_storage[wrestler_array[i]] = "Empty";
        }

        file >> m;
        string rivalries_array[m][2];
        //Getting the first wrestler and the second wrestler and store them into an 2d array
        for(int j=0;j<m;j++){
            file >> first;
            file >> second;
            rivalries_array[j][0] = first;
            rivalries_array[j][1] = second;
        }

        //According to the assignment, the first wrestler in the list is Babyface
        map_storage[wrestler_array[0]] = "Babyface";
        //Calling the bfs function
        bfs(n,m,wrestler_array,rivalries_array,map_storage);
    }
    else{ //If the user enters the inputs wrongly, then I will handle it with error outputs without causing a seg fault

        cout<<"Please enter the correct file"<<endl;
        exit(1);

    }


    return 0;

    
}
