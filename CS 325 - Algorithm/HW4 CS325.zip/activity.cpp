//Name: Hao (Jeff) Deng
//Program: CS325 Assignment 4
//ID: 932912420
//Description: This program first takes the activities from the act.txt file and then
//              sort them and then find the optimized activities.

#include <iostream>
#include <cstdlib>
#include <fstream>
#include <vector>

using namespace std;

//Referencing to my assignment 1 merge sort homework
void merge(vector < vector <int> > &array, int left, int mid, int right){

    //Like the merge sort where we first intialize some values
    int a=left,m=mid,a1=left;

    //Making a temporary 2d vector array for storing
    vector <vector <int> > temp_array;
    temp_array.resize(array.size());

    //Comparing the starting time with the beginning and the middle and see if it's greater
    while(a < mid && m < right){
        //if so, we will take the greater time
        if(array[a][1] > array[m][1])
            temp_array[a1++] = array[a++];
    
        else
            temp_array[a1++] = array[m++];
        
    }

    //Getting the remaining activities
    while(a < mid){
        temp_array[a1++] = array[a++];
    }

    //Getting the remaining activities
    while(m < right){
        temp_array[a1++] = array[m++];

    }


    //After getting all the values into the temporary 2d vectory array, we wil
    //Store them back to the regular 2d vector array because we've passed the array in by reference
    int i=left;
    while(i<right){
        array[i] = temp_array[i];
        i = i + 1;
    }

}


//Sorting algorithm reused from my assignment 1 mergesort.cpp
void sorting(vector < vector <int> > &array, int left, int right){

    // cout<<"left: "<<left<<endl;
    // cout<<"right: "<<right<<endl;
    if(left+1 < right){ 

        //Initialized the middle value and make two recursive calls
        int mid = left + (right-left)/2;
        sorting(array, left, mid);
        sorting(array, mid, right);
    
        //After chopping the array into smaller chunks, we then merge them together
        merge(array, left, mid, right);
    }
}


//This is the main function for taking in the information from the act.txt
//And then sort the activities using merge sort and then select the optimized activities to print them out
int main(){

    ifstream myfile;

    myfile.open("act.txt");

    int num_counter = 0;
    //stops until it reaches to the end of the file
    while(!myfile.eof()){
        num_counter += 1;

        vector < vector <int> > array;
        int set;
        int start_time;
        int finish_time;
        int activity;
        myfile >> set;

        array.resize(set);

        //Grabbing the activities with their start and finish time to a vector array
        for(int i=0; i<set; i++){
            myfile >> activity;
            myfile >> start_time;
            myfile >> finish_time;

            array[i].push_back(activity);
            array[i].push_back(start_time);
            array[i].push_back(finish_time);

        }

        //Calling the merge sort algorithm to sort the activities
        sorting(array,0,set);
        

        //Creating a temporary vector 2d array
        vector < vector <int> > compare;
        compare.push_back(array[0]);

        //This loop is to compare the finish time of an activity with the start
        //time of the next activity. If the start time is greater or equal than the 
        //start time of the next activity in the array, then store the activity
        for(int i=1;i<set;i++){
            if(compare[compare.size()-1][1] >= array[i][2])
                compare.push_back(array[i]);
        }

        //This prints the information of the activities with loop
        cout<<"Set: "<<num_counter<<endl;
        cout<<"Number of activities selected = " <<compare.size()<<endl;
        cout<<"Activities: ";
        for(int j=compare.size()-1;j>=0;j--)
            cout<<compare[j][0]<<" ";

        cout<<endl;
        cout<<endl;

    }


    myfile.close();

}