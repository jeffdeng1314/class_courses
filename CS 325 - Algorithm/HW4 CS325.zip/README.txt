This program is written in C++
Please compile the code with:
    "g++ activity.cpp -o activity"

and then execute the program by enter
    "activity"
in the commandline.

Please make sure that the act.txt file is in the same folder