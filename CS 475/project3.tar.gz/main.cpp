#include <stdlib.h>
#include <stdio.h>
#include <omp.h>
#include <math.h>


unsigned int seed = 0;

float
Ranf( unsigned int *seedp,  float low, float high )
{
        float r = (float) rand_r( seedp );              // 0 - RAND_MAX

        return(   low  +  r * ( high - low ) / (float)RAND_MAX   );
}


int
Ranf( unsigned int *seedp, int ilow, int ihigh )
{
        float low = (float)ilow;
        float high = (float)ihigh + 0.9999f;

        return (int)(  Ranf(seedp, low,high) );
}
float x = Ranf( &seed, -1.f, 1.f );



// State 

int	NowYear;		// 2020 - 2025
int	NowMonth;		// 0 - 11

float	NowPrecip;		// inches of rain per month
float	NowTemp;		// temperature this month
float	NowHeight;		// grain height in inches
int	NowNumDeer;		// number of deer in the current population
int NowNumHunter;  // Number of Hunters in the current population

// Time step
const float GRAIN_GROWS_PER_MONTH =		9.0;
const float ONE_DEER_EATS_PER_MONTH =		1.0;

const float AVG_PRECIP_PER_MONTH =		7.0;	// average
const float AMP_PRECIP_PER_MONTH =		6.0;	// plus or minus
const float RANDOM_PRECIP =			2.0;	// plus or minus noise

const float AVG_TEMP =				60.0;	// average
const float AMP_TEMP =				20.0;	// plus or minus
const float RANDOM_TEMP =			10.0;	// plus or minus noise

const float MIDTEMP =				40.0;
const float MIDPRECIP =				10.0;

const int AVG_Hunter =  2;
int TotalNumMonths;

// Units of grain growth are inches.
// Units of temperature are degrees Fahrenheit (°F).
// Units of precipitation are inches.


float
SQR( float x )
{
        return x*x;
}

void Watcher();
void Grain();
void GrainDeer();
void Hunter();
void TempAndPrecip();
float UnitConverter(float,bool);

int main(){

    TotalNumMonths = 0;
    // starting date and time:
    NowMonth =    0;
    NowYear  = 2020;

    // starting state (feel free to change this if you want):
    NowNumDeer = 3;
    NowHeight =  1.;
    NowNumHunter = 2;


    TempAndPrecip();

    // threads
    omp_set_num_threads( 4 );	// same as # of sections
    #pragma omp parallel sections
    {
        #pragma omp section
        {
            GrainDeer( );
        }

        #pragma omp section
        {
            Grain( );
        }

        #pragma omp section
        {
            Watcher( );
        }

        #pragma omp section
        {
            Hunter( );	// your own
        }
    }       // implied barrier -- all functions must return in order
        // to allow any of them to get past here


}


void Hunter(){

    while( NowYear < 2026 )
    {
        // compute a temporary next-value for this quantity
        // based on the current state of the simulation:
        int TempHunter;

        // hunters are more active during spring time
        if(NowMonth >= 3 && NowMonth <=  5){
            TempHunter = AVG_Hunter + Ranf(&seed,0,10);
        }
        else{
            TempHunter = 1 + Ranf(&seed,-3,4);
        }

        if(TempHunter < 0)
            TempHunter = 0;

        // DoneComputing barrier:
        #pragma omp barrier
            NowNumHunter = TempHunter;

        // DoneAssigning barrier:
        #pragma omp barrier

        // DonePrinting barrier:
        #pragma omp barrier
    }
}

void GrainDeer(){

    while( NowYear < 2026 )
    {
        // compute a temporary next-value for this quantity
        // based on the current state of the simulation:
        int NextNumDeer;
        NextNumDeer = NowNumDeer;

        if((int)NowHeight >= NowNumDeer)
            NextNumDeer += 2;
        else
            NextNumDeer -= 1;

        if(NowNumHunter > 5){
            NextNumDeer -= 4;
        }
        else if(NowNumHunter != 0){
            NextNumDeer -= 1;
        }
        else{

        }


        if(NextNumDeer < 0)
            NextNumDeer = 0;

        // DoneComputing barrier:
        #pragma omp barrier
            NowNumDeer = NextNumDeer;

        // DoneAssigning barrier:
        #pragma omp barrier

        // DonePrinting barrier:
        #pragma omp barrier
    }

}

void Watcher(){
        while( NowYear < 2026 )
    {
        // compute a temporary next-value for this quantity
        // based on the current state of the simulation:

        // DoneComputing barrier:
        #pragma omp barrier


        // DoneAssigning barrier:
        #pragma omp barrier

            printf("mm/yyyy|Totalm: %d/%d, %d\n", NowMonth+1,NowYear,TotalNumMonths+1);
            printf("P|T: %f, %f\n",UnitConverter(NowPrecip,true),UnitConverter(NowTemp,false));
            printf("H|D|Hun: %f, %d, %d\n", UnitConverter(NowHeight,true), NowNumDeer, NowNumHunter);
            printf("\n");
            // printf("%f,%f,%f,%d,%d\n",UnitConverter(NowPrecip,true),UnitConverter(NowTemp,false),UnitConverter(NowHeight,true),NowNumDeer,NowNumHunter);
            NowMonth += 1;
            TotalNumMonths += 1;
            if(NowMonth > 11){
                NowYear += 1;
                NowMonth = 0;
            }
            TempAndPrecip();

        // DonePrinting barrier:
        #pragma omp barrier
    }
}

void Grain(){

    while( NowYear < 2026 )
    {
        // compute a temporary next-value for this quantity
        // based on the current state of the simulation:
        float tempFactor = exp(   -SQR(  ( NowTemp - MIDTEMP ) / 10.  )   );

        float precipFactor = exp(   -SQR(  ( NowPrecip - MIDPRECIP ) / 10.  )   );

        float nextHeight;


        nextHeight = NowHeight;
        nextHeight += tempFactor * precipFactor * GRAIN_GROWS_PER_MONTH;
        nextHeight -= (float)NowNumDeer * ONE_DEER_EATS_PER_MONTH;
        if(nextHeight < 0)
            nextHeight = 0;

        // DoneComputing barrier:
        #pragma omp barrier

            NowHeight = nextHeight;

        // DoneAssigning barrier:
        #pragma omp barrier

        // DonePrinting barrier:
        #pragma omp barrier
    }
}

float UnitConverter(float x, bool cm){

    if(cm){
        return (x * 2.54);
    }
    else{
        return (5. / 9.) * (x - 32.);
    }

}

void TempAndPrecip(){
    // temp and precipitation
    float ang = (  30.*(float)NowMonth + 15.  ) * ( M_PI / 180. );

    float temp = AVG_TEMP - AMP_TEMP * cos( ang );
    NowTemp = temp + Ranf( &seed, -RANDOM_TEMP, RANDOM_TEMP );

    float precip = AVG_PRECIP_PER_MONTH + AMP_PRECIP_PER_MONTH * sin( ang );
    NowPrecip = precip + Ranf( &seed,  -RANDOM_PRECIP, RANDOM_PRECIP );
    if( NowPrecip < 0. )
        NowPrecip = 0.;

}