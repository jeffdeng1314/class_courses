Just compile the code and run it

g++ main.cpp -o main -lm -fopenmp
